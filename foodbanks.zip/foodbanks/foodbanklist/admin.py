from django.contrib import admin
from .forms import *
from .models import *
# Register your models here.

admin.site.register(Foodbank)
admin.site.register(Donation)
admin.site.register(Fundraising)
admin.site.register(Order)









# class StockCreateAdmin(admin.ModelAdmin):
#    list_display = ['foodbank','item_name', 'quantity']
#    form = StockCreateForm
#    search_fields = ['foodbank', 'item_name']

# admin.site.register(Stock)