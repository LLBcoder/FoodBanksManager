from django.apps import AppConfig


class FoodbanklistConfig(AppConfig):
    name = 'foodbanklist'
