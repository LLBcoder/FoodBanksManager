from .models import *
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class DonationForm(forms.ModelForm):
    class Meta :
        model = Donation
        fields = '__all__'

class FundraisingForm(forms.ModelForm):
    class Meta :
        model = Fundraising
        fields = '__all__'

class OrderForm(forms.ModelForm):
    class Meta :
        model = Order
        fields = ['foodbank', 'item', 'qty']


class CreateUserForm(UserCreationForm):
    class Meta :
        model = User
        fields = ['username', 'email', 'password1', 'password2']



















# class StockCreateForm(forms.ModelForm):
#     class Meta:
#         model = Stock
#         fields = ['foodbank', 'item_name', 'quantity']
        
#     def clean_item_name(self):
#         item_name = self.cleaned_data.get('item_name')

#         for instance in Stock.objects.all():
#             if instance.item_name == item_name:
#                 raise forms.ValidationError('This item has already been created')
#         return item_name


# class IssueForm(forms.ModelForm):
# 	class Meta:
# 		model = Stock
# 		fields = ['item_name', 'issue_quantity']

# class ReceiveForm(forms.ModelForm):
# 	class Meta:
# 		model = Stock
# 		fields = ['item_name', 'receive_quantity', 'receive_by']