from django.db import models

# Create your models here.
from django.db import models

# Create your models here.
class Foodbank(models.Model):
    name = models.CharField(max_length=200)
    adress = models.CharField(max_length=200)
    phone = models.CharField(max_length=12)

    def __str__(self):
        return self.name


item_choice = (
		('Flour', 'Flour'),
		('Can beef', 'Can beef'),
		('Tomato sauce can', 'Tomato sauce can'),
        ('Cereal box', 'Cereal box'),
        ('Bag of rice', 'Bag of rice'),
        ('Pasta box', 'Pasta box'),
        ('Bag of sugar', 'Bag of sugar'),
        ('Pint milk', 'Pint milk'),
        ('Coffee kit', 'Coffee kit'),
	)

class Donation(models.Model):
    foodbank = models.ForeignKey(Foodbank, on_delete= models.CASCADE)
    name = models.CharField(max_length=200)
    date = models.DateField(auto_now_add=True)
    item = models.CharField(max_length=200, choices=item_choice)
    qty = models.IntegerField()

    def __str__(self):
        return self.name


class Fundraising(models.Model):
    foodbank = models.ForeignKey(Foodbank, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    date = models.DateField(auto_now_add=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name


class Order(models.Model):
    foodbank = models.ForeignKey(Foodbank, on_delete=models.CASCADE)
    item = models.CharField(max_length=200, choices=item_choice)
    qty = models.IntegerField()

    def __str__(self):
        return self.item





















# class Stock(models.Model):
#     foodbank = models.ForeignKey(Foodbank, on_delete=models.CASCADE)
#     item_name = models.CharField(max_length=50, blank=True, null=True, choices=item_choice)
#     quantity = models.IntegerField(default='0', blank=True, null=True)
#     receive_quantity = models.IntegerField(default='0', blank=True, null=True)
#     receive_by = models.CharField(max_length=50, blank=True, null=True)
#     receive_date = models.DateField(auto_now_add=True, blank=True)
#     issue_quantity = models.IntegerField(default='0', blank=True, null=True)

#     def __str__(self):
#         return self.item_name
