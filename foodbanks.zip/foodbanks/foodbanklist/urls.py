from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('admin/<str:name>/', views.foodbank, name='foodbank'),
    path('create_order/<str:pk>/', views.order, name='order'),
    path('create_donation/<str:pk>/', views.createDonation, name='createdonation'),
    path('edit_donation/<str:pk>/', views.editDonation, name='editdonation'),
    path('delete_donation/<str:pk>/', views.deleteDonation, name='deletedonation'),
    path('create_fundraising/<str:pk>/', views.createFundraising, name='createfundraising'),
    path('edit_fundraising/<str:pk>/', views.editFundraising, name='editfundraising'),
    path('delete_fundraising/<str:pk>/', views.deleteFundraising, name='deletefundraising'),
    path('register', views.registerPage, name='register'),
    path('login', views.loginPage, name='login'),
    path('logout', views.logoutPage, name='logout'),

    path('user/<str:name>/', views.foodbankuser, name='foodbankuser'),


    
    # path('new/new/', views.new, name='new'),
    # path('receive_items/<str:pk>/', views.receive_items, name="receive_items"),
    # path('issue_items/<str:pk>/', views.issue_items, name="issue_items"),
]