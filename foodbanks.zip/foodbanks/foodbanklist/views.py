from django.shortcuts import render, redirect
from django.forms import inlineformset_factory
from datetime import datetime
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group



from .models import *
from .forms import *
from .decorators import *

# Create your views here

def home(request):

    foodbanks = Foodbank.objects.all()
    donations = Donation.objects.all()
    fundraising = Fundraising.objects.all()
    orders = Order.objects.all()

    totaldonations = 0
    for fund in fundraising:
        totaldonations += fund.amount 
    print(totaldonations)

    totalorders = len(orders)

    monthdonations = 0
    monthfundraising = fundraising.filter(date__month=datetime.now().month)
    for fund in monthfundraising:
        monthdonations += fund.amount   

    return render(request, 'foodbanklist/index.html', {'foodbanks':foodbanks, 'totaldonations':totaldonations, 'totalorders':totalorders, 'monthdonations':monthdonations})

@unauthenticated_user
def registerPage(request):

    form = CreateUserForm()
    if request.method=='POST' :
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            messages.success(request, 'Account was created for '+ username)
            return redirect('/login')

    foodbanks = Foodbank.objects.all()
    context = {'foodbanks':foodbanks, 'form':form}

    return render(request, 'foodbanklist/register.html', context)

@unauthenticated_user
def loginPage(request):

    if request.method=='POST' :
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)

        if user is not None :
            login(request, user)
            return redirect('/')
        else :
            messages.info(request, 'Username or password is incorrect')
            return redirect('/login')

    foodbanks = Foodbank.objects.all()
    context = {'foodbanks':foodbanks}

    return render(request, 'foodbanklist/login.html', context)



@login_required(login_url='login')
def logoutPage(request):
    logout(request)
    return redirect('login')



def foodbank(request, name):
    foodbank = Foodbank.objects.get(name=name)

    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != name.split()[0]:
            return redirect('/user/'+name)
            
        else :    
            foodbanks = Foodbank.objects.all()
            donations = foodbank.donation_set.all()
            fundraising = foodbank.fundraising_set.all()
            orders = foodbank.order_set.all()


        #Create the inventory
            alldonations = {}
            for donation in donations :
                alldonations[donation.item]= alldonations.get(donation.item,0) + donation.qty
            print(alldonations)

            allorders = {}
            for order in orders :
                allorders[order.item]=allorders.get(order.item, 0) + order.qty
            print(allorders)

            inventory = {}
            for k,v in alldonations.items():
                if k in allorders.keys():
                    inventory[k] = v - allorders[k]
                else :
                    inventory[k] = v
            
            print(inventory)



            totaldonations = 0
            for fund in fundraising:
                totaldonations += fund.amount 

            monthdonations = 0
            monthfundraising = foodbank.fundraising_set.filter(date__month=datetime.now().month)
            for fund in monthfundraising:
                monthdonations += fund.amount

            totalorders = len(orders)

            context = {'foodbanks':foodbanks, 'foodbank':foodbank, 'donations':donations, 'fundraising':fundraising, 'inventory':inventory, 'totaldonations':totaldonations, 'monthdonations':monthdonations, 'totalorders':totalorders}
            
            return render(request, 'foodbanklist/foodbank.html', context)


#Donation    
def createDonation(request, pk):
    
    foodbank = Foodbank.objects.get(id=pk)

    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :    
            DonationFormSet = inlineformset_factory(Foodbank, Donation, fields=('name', 'item', 'qty'), extra=5)

            
            formset = DonationFormSet(queryset=Donation.objects.none(), instance=foodbank)

            if request.method=='POST' :
                formset = DonationFormSet(request.POST, instance=foodbank)
                if formset.is_valid():
                    formset.save()
                    return redirect('/admin/'+foodbank.name)

            foodbanks = Foodbank.objects.all()
            context = {'formset': formset, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/createdonation.html', context)


def editDonation(request, pk):

    donation = Donation.objects.get(id=pk)
    
    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != donation.foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :    
            form = DonationForm(instance=donation)

            if request.method =='POST' :
                form = DonationForm(request.POST, instance=donation)
                if form.is_valid():
                    form.save()
                    return redirect('/admin/'+donation.foodbank.name)

            foodbanks = Foodbank.objects.all()
            context = {'form': form, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/editdonation.html', context)


def deleteDonation(request, pk):

    donation = Donation.objects.get(id=pk)
    
    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != donation.foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :    
            if request.method == 'POST':
                donation.delete()
                return redirect('/admin/'+donation.foodbank.name)

            foodbanks = Foodbank.objects.all()
            context = {'donation': donation, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/deletedonation.html', context)


#Fundraising

def createFundraising(request, pk):
    foodbank = Foodbank.objects.get(id=pk)

    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :    
            DonationFormSet = inlineformset_factory(Foodbank, Fundraising, fields=('name', 'amount'), extra=1)

            formset = DonationFormSet(queryset=Donation.objects.none(), instance=foodbank)

            if request.method=='POST' :
                formset = DonationFormSet(request.POST, instance=foodbank)
                if formset.is_valid():
                    formset.save()
                    return redirect('/admin/'+foodbank.name)

            foodbanks = Foodbank.objects.all()
            context = {'formset': formset, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/createfundraising.html', context)


def editFundraising(request, pk):
    fundraising = Fundraising.objects.get(id=pk)
    
    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != fundraising.foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :   
            form = FundraisingForm(instance=fundraising)

            if request.method =='POST' :
                form = FundraisingForm(request.POST, instance=fundraising)
                if form.is_valid():
                    form.save()
                    return redirect('/admin/'+fundraising.foodbank.name)

                foodbanks = Foodbank.objects.all()
                context = {'form': form, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/editfundraising.html', context)


def deleteFundraising(request, pk):
    fundraising = Fundraising.objects.get(id=pk)
    
    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != fundraising.foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :   
            if request.method == 'POST':
                fundraising.delete()
                return redirect('/admin/'+fundraising.foodbank.name)

            foodbanks = Foodbank.objects.all()
            context = {'fundraising': fundraising, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/deletefundraising.html', context)


def order(request, pk):
    foodbank = Foodbank.objects.get(id=pk)

    if len(request.user.groups.all()) == 0:
        return redirect('/user/'+foodbank.name)

    if len(request.user.groups.all()) > 0:
        if request.user.groups.all()[0].name != foodbank.name.split()[0]:
            return redirect('/user/'+foodbank.name)
            
        else :    
            OrderFormSet = inlineformset_factory(Foodbank, Order, fields=('item', 'qty'), extra=8)

            formset = OrderFormSet(queryset=Order.objects.none(), instance=foodbank)

            if request.method=='POST' :
                formset = OrderFormSet(request.POST, instance=foodbank)
                if formset.is_valid():
                    formset.save()
                    return redirect('/admin/'+foodbank.name)

            foodbanks = Foodbank.objects.all()
            context = {'formset': formset, 'foodbanks':foodbanks}

            return render(request, 'foodbanklist/orders.html', context)





#Views for user interface
def foodbankuser(request, name):
 
    foodbanks = Foodbank.objects.all()

    foodbank = Foodbank.objects.get(name=name)
    fundraising = foodbank.fundraising_set.all()
    orders = foodbank.order_set.all()


    totaldonations = 0
    for fund in fundraising:
        totaldonations += fund.amount 

    monthdonations = 0
    monthfundraising = foodbank.fundraising_set.filter(date__month=datetime.now().month)
    for fund in monthfundraising:
        monthdonations += fund.amount

    totalorders = len(orders)

    context = {'foodbanks':foodbanks, 'foodbank':foodbank, 'totaldonations':totaldonations, 'monthdonations':monthdonations, 'totalorders':totalorders}
    
    return render(request, 'foodbanklist/foodbankuser.html', context)




















# def new(request):

#     stocks = Stock.objects.all()

# #Add items to the inventory
#     form = StockCreateForm(request.POST or None)
#     if form.is_valid():
#         form.save()
#         return redirect('/new/new/')



#     foodbanks = Foodbank.objects.all()
#     context = {"form": form, 'foodbanks':foodbanks, 'stocks':stocks}
#     return render(request, 'foodbanklist/new.html', context)




# #Add donation to the inventory

# def receive_items(request, pk):
# 	queryset = Stock.objects.get(id=pk)
# 	form = ReceiveForm(request.POST or None, instance=queryset)
# 	if form.is_valid():
# 		instance = form.save(commit=False)
# 		instance.quantity += instance.receive_quantity
# 		instance.save()

# 		return redirect('/new/new')
		
# 	context = {
# 			"instance": queryset,
# 			"form": form,
# 		}
# 	return render(request, "foodbanklist/add_items.html", context)

# def issue_items(request, pk):
# 	queryset = Stock.objects.get(id=pk)
# 	form = IssueForm(request.POST or None, instance=queryset)
# 	if form.is_valid():
# 		instance = form.save(commit=False)
# 		instance.quantity -= instance.issue_quantity
# 		instance.save()

# 		return redirect('/new/new')

# 	context = {
# 		"queryset": queryset,
# 		"form": form,
# 	}
# 	return render(request, "foodbanklist/minus_items.html", context)







